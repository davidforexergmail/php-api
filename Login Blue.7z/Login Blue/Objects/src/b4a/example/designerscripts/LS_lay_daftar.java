package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lay_daftar{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[lay_daftar/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 3;BA.debugLine="imgLogo.VerticalCenter = Label1.VerticalCenter"[lay_daftar/General script]
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2) - (views.get("imglogo").vw.getHeight() / 2)));
//BA.debugLineNum = 4;BA.debugLine="imgLogo.Top = Label1.VerticalCenter/2.8"[lay_daftar/General script]
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)/2.8d));
//BA.debugLineNum = 5;BA.debugLine="lblLogo.Top = Label2.top + 60"[lay_daftar/General script]
views.get("lbllogo").vw.setTop((int)((views.get("label2").vw.getTop())+60d));
//BA.debugLineNum = 6;BA.debugLine="lblLogo.HorizontalCenter = imgLogo.HorizontalCenter"[lay_daftar/General script]
views.get("lbllogo").vw.setLeft((int)((views.get("imglogo").vw.getLeft() + views.get("imglogo").vw.getWidth()/2) - (views.get("lbllogo").vw.getWidth() / 2)));
//BA.debugLineNum = 8;BA.debugLine="Label2.Top = Label1.VerticalCenter + 100"[lay_daftar/General script]
views.get("label2").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)+100d));
//BA.debugLineNum = 9;BA.debugLine="Label2.Width = Label1.Width"[lay_daftar/General script]
views.get("label2").vw.setWidth((int)((views.get("label1").vw.getWidth())));
//BA.debugLineNum = 10;BA.debugLine="Label2.Left = Label1.Left"[lay_daftar/General script]
views.get("label2").vw.setLeft((int)((views.get("label1").vw.getLeft())));
//BA.debugLineNum = 11;BA.debugLine="Label2.Height = Label1.Height/2"[lay_daftar/General script]
views.get("label2").vw.setHeight((int)((views.get("label1").vw.getHeight())/2d));
//BA.debugLineNum = 13;BA.debugLine="imgPhoto.Top = imgLogo.Bottom + 20"[lay_daftar/General script]
views.get("imgphoto").vw.setTop((int)((views.get("imglogo").vw.getTop() + views.get("imglogo").vw.getHeight())+20d));
//BA.debugLineNum = 14;BA.debugLine="imgPhoto.Left = Label1.Left"[lay_daftar/General script]
views.get("imgphoto").vw.setLeft((int)((views.get("label1").vw.getLeft())));
//BA.debugLineNum = 15;BA.debugLine="imgPhoto.Width = 210"[lay_daftar/General script]
views.get("imgphoto").vw.setWidth((int)(210d));
//BA.debugLineNum = 16;BA.debugLine="imgPhoto.Height = 210"[lay_daftar/General script]
views.get("imgphoto").vw.setHeight((int)(210d));
//BA.debugLineNum = 18;BA.debugLine="Label3.Top = lblLogo.Bottom + 80"[lay_daftar/General script]
views.get("label3").vw.setTop((int)((views.get("lbllogo").vw.getTop() + views.get("lbllogo").vw.getHeight())+80d));
//BA.debugLineNum = 19;BA.debugLine="Label3.HorizontalCenter = lblLogo.HorizontalCenter"[lay_daftar/General script]
views.get("label3").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2) - (views.get("label3").vw.getWidth() / 2)));
//BA.debugLineNum = 20;BA.debugLine="txtUser.top = Label3.Top"[lay_daftar/General script]
views.get("txtuser").vw.setTop((int)((views.get("label3").vw.getTop())));
//BA.debugLineNum = 21;BA.debugLine="txtUser.Left = Label3.Left + 60"[lay_daftar/General script]
views.get("txtuser").vw.setLeft((int)((views.get("label3").vw.getLeft())+60d));
//BA.debugLineNum = 22;BA.debugLine="imguser.top = Label3.top + 20"[lay_daftar/General script]
views.get("imguser").vw.setTop((int)((views.get("label3").vw.getTop())+20d));
//BA.debugLineNum = 23;BA.debugLine="imguser.Left = Label3.left + 10"[lay_daftar/General script]
views.get("imguser").vw.setLeft((int)((views.get("label3").vw.getLeft())+10d));
//BA.debugLineNum = 24;BA.debugLine="imguser.Width = 40"[lay_daftar/General script]
views.get("imguser").vw.setWidth((int)(40d));
//BA.debugLineNum = 25;BA.debugLine="imguser.Height = 40"[lay_daftar/General script]
views.get("imguser").vw.setHeight((int)(40d));
//BA.debugLineNum = 28;BA.debugLine="Label4.Top = Label3.Bottom + 20"[lay_daftar/General script]
views.get("label4").vw.setTop((int)((views.get("label3").vw.getTop() + views.get("label3").vw.getHeight())+20d));
//BA.debugLineNum = 29;BA.debugLine="Label4.HorizontalCenter = lblLogo.HorizontalCenter"[lay_daftar/General script]
views.get("label4").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2) - (views.get("label4").vw.getWidth() / 2)));
//BA.debugLineNum = 30;BA.debugLine="txtPwd.Top = Label4.top"[lay_daftar/General script]
views.get("txtpwd").vw.setTop((int)((views.get("label4").vw.getTop())));
//BA.debugLineNum = 31;BA.debugLine="txtPwd.Left = Label4.Left + 60"[lay_daftar/General script]
views.get("txtpwd").vw.setLeft((int)((views.get("label4").vw.getLeft())+60d));
//BA.debugLineNum = 32;BA.debugLine="imgPwd.Top = Label4.Top + 20"[lay_daftar/General script]
views.get("imgpwd").vw.setTop((int)((views.get("label4").vw.getTop())+20d));
//BA.debugLineNum = 33;BA.debugLine="imgPwd.Left = Label4.left + 10"[lay_daftar/General script]
views.get("imgpwd").vw.setLeft((int)((views.get("label4").vw.getLeft())+10d));
//BA.debugLineNum = 34;BA.debugLine="imgPwd.Width = 40"[lay_daftar/General script]
views.get("imgpwd").vw.setWidth((int)(40d));
//BA.debugLineNum = 35;BA.debugLine="imgPwd.Height = 40"[lay_daftar/General script]
views.get("imgpwd").vw.setHeight((int)(40d));
//BA.debugLineNum = 37;BA.debugLine="Label5.Top = Label4.Bottom + 20"[lay_daftar/General script]
views.get("label5").vw.setTop((int)((views.get("label4").vw.getTop() + views.get("label4").vw.getHeight())+20d));
//BA.debugLineNum = 38;BA.debugLine="Label5.HorizontalCenter = lblLogo.HorizontalCenter"[lay_daftar/General script]
views.get("label5").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2) - (views.get("label5").vw.getWidth() / 2)));
//BA.debugLineNum = 39;BA.debugLine="txtEmail.Top = Label5.top"[lay_daftar/General script]
views.get("txtemail").vw.setTop((int)((views.get("label5").vw.getTop())));
//BA.debugLineNum = 40;BA.debugLine="txtEmail.Left = Label5.Left + 60"[lay_daftar/General script]
views.get("txtemail").vw.setLeft((int)((views.get("label5").vw.getLeft())+60d));
//BA.debugLineNum = 41;BA.debugLine="imgEmail.Top = Label5.Top + 20"[lay_daftar/General script]
views.get("imgemail").vw.setTop((int)((views.get("label5").vw.getTop())+20d));
//BA.debugLineNum = 42;BA.debugLine="imgEmail.Left = Label5.left + 10"[lay_daftar/General script]
views.get("imgemail").vw.setLeft((int)((views.get("label5").vw.getLeft())+10d));
//BA.debugLineNum = 43;BA.debugLine="imgEmail.Width = 40"[lay_daftar/General script]
views.get("imgemail").vw.setWidth((int)(40d));
//BA.debugLineNum = 44;BA.debugLine="imgEmail.Height = 40"[lay_daftar/General script]
views.get("imgemail").vw.setHeight((int)(40d));
//BA.debugLineNum = 47;BA.debugLine="imgView.top = Label4.top +20"[lay_daftar/General script]
views.get("imgview").vw.setTop((int)((views.get("label4").vw.getTop())+20d));
//BA.debugLineNum = 48;BA.debugLine="imgView.Left = Label4.Right - 60"[lay_daftar/General script]
views.get("imgview").vw.setLeft((int)((views.get("label4").vw.getLeft() + views.get("label4").vw.getWidth())-60d));
//BA.debugLineNum = 49;BA.debugLine="imgView.Width = 40"[lay_daftar/General script]
views.get("imgview").vw.setWidth((int)(40d));
//BA.debugLineNum = 50;BA.debugLine="imgView.Height = 40"[lay_daftar/General script]
views.get("imgview").vw.setHeight((int)(40d));
//BA.debugLineNum = 53;BA.debugLine="btnBatal.Top=Label5.Bottom + 100"[lay_daftar/General script]
views.get("btnbatal").vw.setTop((int)((views.get("label5").vw.getTop() + views.get("label5").vw.getHeight())+100d));
//BA.debugLineNum = 54;BA.debugLine="btnBatal.HorizontalCenter = lblLogo.HorizontalCenter - 120"[lay_daftar/General script]
views.get("btnbatal").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2)-120d - (views.get("btnbatal").vw.getWidth() / 2)));
//BA.debugLineNum = 55;BA.debugLine="btnDaftar.Top=Label5.Bottom + 100"[lay_daftar/General script]
views.get("btndaftar").vw.setTop((int)((views.get("label5").vw.getTop() + views.get("label5").vw.getHeight())+100d));
//BA.debugLineNum = 56;BA.debugLine="btnDaftar.HorizontalCenter = lblLogo.HorizontalCenter + 120"[lay_daftar/General script]
views.get("btndaftar").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2)+120d - (views.get("btndaftar").vw.getWidth() / 2)));

}
}