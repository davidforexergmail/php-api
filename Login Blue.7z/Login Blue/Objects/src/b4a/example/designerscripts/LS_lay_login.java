package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lay_login{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2) - (views.get("imglogo").vw.getHeight() / 2)));
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)/2.8d));
views.get("lbllogo").vw.setTop((int)((views.get("imglogo").vw.getTop() + views.get("imglogo").vw.getHeight())+120d));
views.get("lbllogo").vw.setLeft((int)((views.get("imglogo").vw.getLeft() + views.get("imglogo").vw.getWidth()/2) - (views.get("lbllogo").vw.getWidth() / 2)));
views.get("label2").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)+100d));
views.get("label2").vw.setWidth((int)((views.get("label1").vw.getWidth())));
views.get("label2").vw.setLeft((int)((views.get("label1").vw.getLeft())));
views.get("label2").vw.setHeight((int)((views.get("label1").vw.getHeight())/2d));
views.get("label3").vw.setTop((int)((views.get("lbllogo").vw.getTop() + views.get("lbllogo").vw.getHeight())+80d));
views.get("label3").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2) - (views.get("label3").vw.getWidth() / 2)));
views.get("txtuser").vw.setTop((int)((views.get("label3").vw.getTop())));
views.get("txtuser").vw.setLeft((int)((views.get("label3").vw.getLeft())+60d));
views.get("imguser").vw.setTop((int)((views.get("label3").vw.getTop())+20d));
views.get("imguser").vw.setLeft((int)((views.get("label3").vw.getLeft())+10d));
views.get("imguser").vw.setWidth((int)(40d));
views.get("imguser").vw.setHeight((int)(40d));
views.get("label4").vw.setTop((int)((views.get("label3").vw.getTop() + views.get("label3").vw.getHeight())+20d));
views.get("label4").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2) - (views.get("label4").vw.getWidth() / 2)));
views.get("txtpwd").vw.setTop((int)((views.get("label4").vw.getTop())));
views.get("txtpwd").vw.setLeft((int)((views.get("label4").vw.getLeft())+60d));
views.get("imgpwd").vw.setTop((int)((views.get("label4").vw.getTop())+20d));
views.get("imgpwd").vw.setLeft((int)((views.get("label4").vw.getLeft())+10d));
views.get("imgpwd").vw.setWidth((int)(40d));
views.get("imgpwd").vw.setHeight((int)(40d));
views.get("imgview").vw.setTop((int)((views.get("label4").vw.getTop())+20d));
views.get("imgview").vw.setLeft((int)((views.get("label4").vw.getLeft() + views.get("label4").vw.getWidth())-60d));
views.get("imgview").vw.setWidth((int)(40d));
views.get("imgview").vw.setHeight((int)(40d));
views.get("btnbatal").vw.setTop((int)((views.get("label4").vw.getTop() + views.get("label4").vw.getHeight())+100d));
views.get("btnbatal").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2)-120d - (views.get("btnbatal").vw.getWidth() / 2)));
views.get("btnlogin").vw.setTop((int)((views.get("label4").vw.getTop() + views.get("label4").vw.getHeight())+100d));
views.get("btnlogin").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2)+120d - (views.get("btnlogin").vw.getWidth() / 2)));
views.get("lbldaftar").vw.setTop((int)((views.get("btnlogin").vw.getTop() + views.get("btnlogin").vw.getHeight())+220d));
views.get("lbldaftar").vw.setLeft((int)((views.get("lbllogo").vw.getLeft() + views.get("lbllogo").vw.getWidth()/2)-180d - (views.get("lbldaftar").vw.getWidth() / 2)));
views.get("lbllupapwd").vw.setTop((int)((views.get("btnlogin").vw.getTop() + views.get("btnlogin").vw.getHeight())+220d));

}
}