package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lay_lupapwd{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2) - (views.get("imglogo").vw.getHeight() / 2)));
views.get("imglogo").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)/2.8d));
views.get("lbllupa").vw.setTop((int)((views.get("imglogo").vw.getTop() + views.get("imglogo").vw.getHeight())+120d));
views.get("lbllupa").vw.setLeft((int)((views.get("imglogo").vw.getLeft() + views.get("imglogo").vw.getWidth()/2) - (views.get("lbllupa").vw.getWidth() / 2)));
views.get("label2").vw.setTop((int)((views.get("label1").vw.getTop() + views.get("label1").vw.getHeight()/2)+100d));
views.get("label2").vw.setWidth((int)((views.get("label1").vw.getWidth())));
views.get("label2").vw.setLeft((int)((views.get("label1").vw.getLeft())));
views.get("label2").vw.setHeight((int)((views.get("label1").vw.getHeight())/2d));
views.get("label3").vw.setTop((int)((views.get("lbllupa").vw.getTop() + views.get("lbllupa").vw.getHeight())+60d));
views.get("label3").vw.setLeft((int)((views.get("lbllupa").vw.getLeft() + views.get("lbllupa").vw.getWidth()/2) - (views.get("label3").vw.getWidth() / 2)));
views.get("txtuser").vw.setTop((int)((views.get("label3").vw.getTop())));
views.get("txtuser").vw.setLeft((int)((views.get("label3").vw.getLeft())+60d));
views.get("imguser").vw.setTop((int)((views.get("label3").vw.getTop())+20d));
views.get("imguser").vw.setLeft((int)((views.get("label3").vw.getLeft())+10d));
views.get("imguser").vw.setWidth((int)(40d));
views.get("imguser").vw.setHeight((int)(40d));
views.get("label5").vw.setTop((int)((views.get("label3").vw.getTop() + views.get("label3").vw.getHeight())+40d));
views.get("label5").vw.setLeft((int)((views.get("lbllupa").vw.getLeft() + views.get("lbllupa").vw.getWidth()/2) - (views.get("label5").vw.getWidth() / 2)));
views.get("txtemail").vw.setTop((int)((views.get("label5").vw.getTop())));
views.get("txtemail").vw.setLeft((int)((views.get("label5").vw.getLeft())+60d));
views.get("imgemail").vw.setTop((int)((views.get("label5").vw.getTop())+15d));
views.get("imgemail").vw.setLeft((int)((views.get("label5").vw.getLeft())+6d));
views.get("imgemail").vw.setWidth((int)(45d));
views.get("imgemail").vw.setHeight((int)(45d));
views.get("btnbatal").vw.setTop((int)((views.get("label5").vw.getTop() + views.get("label5").vw.getHeight())+150d));
views.get("btnbatal").vw.setLeft((int)((views.get("lbllupa").vw.getLeft() + views.get("lbllupa").vw.getWidth()/2)-120d - (views.get("btnbatal").vw.getWidth() / 2)));
views.get("btnkirim").vw.setTop((int)((views.get("label5").vw.getTop() + views.get("label5").vw.getHeight())+150d));
views.get("btnkirim").vw.setLeft((int)((views.get("lbllupa").vw.getLeft() + views.get("lbllupa").vw.getWidth()/2)+120d - (views.get("btnkirim").vw.getWidth() / 2)));

}
}